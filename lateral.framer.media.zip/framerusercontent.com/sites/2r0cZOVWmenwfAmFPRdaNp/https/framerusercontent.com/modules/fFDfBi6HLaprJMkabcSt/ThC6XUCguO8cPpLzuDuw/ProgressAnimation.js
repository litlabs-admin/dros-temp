import {
    jsx as _jsx,
    jsxs as _jsxs
} from "react/jsx-runtime";
import {
    useEffect,
    useState
} from "react";
import {
    addPropertyControls,
    ControlType
} from "framer";
export default function ProgressAnimation(props) {
    const {
        backgroundColor,
        progressColor,
        timeAnimation
    } = props;
    const [width, setWidth] = useState(0);
    useEffect(function() {
        const interval = setInterval(function() {
            setWidth(prevWidth => prevWidth >= 100 ? 0 : prevWidth + 1);
        }, timeAnimation);
        return function cleanup() {
            clearInterval(interval);
        };
    }, [timeAnimation]);
    const styles = {
        container: {
            width: "100%",
            height: "100%",
            position: "relative",
            overflow: "hidden"
        },
        background: {
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            background: backgroundColor
        },
        progress: {
            position: "absolute",
            top: 0,
            left: 0,
            height: "100%",
            width: `${width}%`,
            background: progressColor,
            transition: `width ${timeAnimation}ms linear`
        }
    };
    return /*#__PURE__*/ _jsxs("div", {
        style: styles.container,
        children: [ /*#__PURE__*/ _jsx("div", {
            style: styles.background
        }), /*#__PURE__*/ _jsx("div", {
            style: styles.progress
        })]
    });
}
addPropertyControls(ProgressAnimation, {
    backgroundColor: {
        title: "Background Color",
        type: ControlType.Color,
        defaultValue: "rgba(0, 0, 0, 0.12)"
    },
    progressColor: {
        title: "Progress Color",
        type: ControlType.Color,
        defaultValue: "black"
    },
    timeAnimation: {
        title: "Animation Time (ms)",
        type: ControlType.Number,
        defaultValue: 50,
        min: 10,
        max: 1e3,
        step: 10
    }
});
export const __FramerMetadata__ = {
    "exports": {
        "default": {
            "type": "reactComponent",
            "name": "ProgressAnimation",
            "slots": [],
            "annotations": {
                "framerContractVersion": "1"
            }
        },
        "__FramerMetadata__": {
            "type": "variable"
        }
    }
}
//# sourceMappingURL=./ProgressAnimation.map