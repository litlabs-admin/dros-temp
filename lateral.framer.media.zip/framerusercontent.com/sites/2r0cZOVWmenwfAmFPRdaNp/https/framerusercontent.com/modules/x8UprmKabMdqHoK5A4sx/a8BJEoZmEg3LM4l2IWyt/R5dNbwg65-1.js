// src/code-generation/components/cms/bundled/getRichTextJsonResolver.tsx?bundle
import {
    jsx as e
} from "react/jsx-runtime";
import {
    AutoBreakpointVariant as t,
    ComponentPresetsConsumer as r,
    Link as n,
    motion as o
} from "framer"; // ../../library/src/router/lazy.tsx
import {
    isValidElement as i
} from "react"; // ../../library/src/utils/utils.ts
var a, l = "undefined" != typeof window,
    f = l && "function" == typeof window.requestIdleCallback,
    u = "preload";

function c(e) {
    return "object" == typeof e && null !== e && ! /*#__PURE__*/ i(e) && u in e;
} // src/code-generation/components/cms/bundled/getRichTextJsonResolver.tsx?bundle
import {
    Fragment as p,
    createElement as s
} from "react"; // src/code-generation/components/cms/bundled/assert.ts
function m(e, ...t) {
    if (!e) throw Error("Assertion Error" + (t.length > 0 ? ": " + t.join(" ") : ""));
} // src/code-generation/components/cms/bundled/getRichTextJsonResolver.tsx?bundle
var d = ((a = d || {})[a.Fragment = 1] = "Fragment", a[a.Link = 2] = "Link", a[a.Module = 3] = "Module", a[a.Tag = 4] = "Tag", a[a.Text = 5] = "Text", a);

function g(i) {
    let a = /* @__PURE__ */ new Map;
    return l => {
        let f = a.get(l);
        if (f) return f;
        let u = JSON.parse(l),
            d = function a(l) {
                switch (l[0]) {
                    case 1 /* Fragment */ :
                        {
                            let [, ...e] = l,
                            t = e.map(a);
                            return /*#__PURE__*/ s(p, void 0, ...t);
                        }
                    case 2 /* Link */ :
                        {
                            let [, e, ...t] = l,
                            r = t.map(a);
                            return /*#__PURE__*/ s(n, e, ...r);
                        }
                    case 3 /* Module */ :
                        {
                            let [, n, o, f, u] = l;
                            for (let e of f) {
                                let t = o[e];
                                t && (o[e] = a(t));
                            }
                            for (let e of u) {
                                let t = o[e];
                                if ("string" != typeof t) continue;
                                let r = i[t];
                                r && (c(r) && r.preload(), o[e] = r);
                            }
                            let p = i[n];
                            return m(p, "Module not found"),
                            c(p) && p.preload(),
                            /*#__PURE__*/ e(r, {
                                componentIdentifier: n,
                                children: r => /*#__PURE__*/ e(t, {
                                    component: p,
                                    props: { ...r,
                                        ...o
                                    }
                                })
                            });
                        }
                    case 4 /* Tag */ :
                        {
                            let [, e, t, ...r] = l,
                            n = r.map(a);
                            if ("a" === e) return /*#__PURE__*/ s(o.a, t, ...n);
                            return /*#__PURE__*/ s(e, t, ...n);
                        }
                    case 5 /* Text */ :
                        {
                            let [, e] = l;
                            return e;
                        }
                }
            }(u);
        return a.set(l, d), d;
    };
}
export {
    d as RichTextJsonType, g as getRichTextJsonResolver
};
export const __FramerMetadata__ = {
    "exports": {
        "getRichTextJsonResolver": {
            "type": "reactComponent",
            "name": "getRichTextJsonResolver",
            "slots": [],
            "annotations": {
                "framerContractVersion": "1"
            }
        },
        "RichTextJsonType": {
            "type": "variable",
            "annotations": {
                "framerContractVersion": "1"
            }
        },
        "__FramerMetadata__": {
            "type": "variable"
        }
    }
}